﻿#include <iostream>

int nieparzystySkrot(int n) {
    int m = 0;
    int number = 1;

    while (n > 0) {
        int number2 = n % 10;
        if (number2 % 2 == 1) {
            m = m + number2 * number;
            number = number * 10;
        }
        n = n / 10;
    }

    return m;
}

int main() {
    int n;
    std::cin >> n;
    std::cout << nieparzystySkrot(n) << '\n';
    return 0;
}