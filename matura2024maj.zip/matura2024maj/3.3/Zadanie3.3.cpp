﻿#include <iostream>
#include <fstream>

using namespace std;

int nwd(int a, int b) {
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int nieparzystySkrot(int liczba) {
    for (int i = liczba; i >= 1; i--) {
        if (liczba % i == 0 && i % 2 == 1) {
            return i; 
        }
    }
}

int main() {
    ifstream plik("skrot2.txt");
    int liczba;

    while (plik >> liczba) {
        int skrot = nieparzystySkrot(liczba);
        int wspDzielnik = nwd(liczba, skrot);

        if (wspDzielnik == 7) {
            cout << liczba << "\n";
        }
    }

    plik.close();
    return 0;
}