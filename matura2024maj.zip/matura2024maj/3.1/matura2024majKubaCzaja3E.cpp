﻿#include <iostream>

int nieparzysty_skrot(int n) {
    while (n % 2 == 0) {
        n /= 2;
    }
    return n;
}

int main() {
    int n;
    std::cin >> n;
    std::cout << nieparzysty_skrot(n) << "\n";
    return 0;
}