﻿#include <iostream>
#include <fstream>

using namespace std;

bool tylkoParzyste(int liczba) {
    while (liczba > 0) {
        int cyfra = liczba % 10;
        if (cyfra % 2 == 1) {
            return false;
        }
        liczba /= 10;
    }
    return true;
}

int main() {
    ifstream plik("skrot.txt");
    ofstream wynik("wyniki3_2.txt");

    if (!plik) {
        cout << "Blad otwierania pliku skrot.txt\n";
        return 1;
    }
    if (!wynik) {
        cout << "Blad otwierania pliku wyniki3_2.txt\n";
        return 1;
    }

    int liczba, ileBezSkrotu = 0, maxBezSkrotu = 0;

    while (plik >> liczba) {
        if (tylkoParzyste(liczba)) {
            ileBezSkrotu++;
            if (liczba > maxBezSkrotu) {
                maxBezSkrotu = liczba;
            }
        }
    }

    wynik << ileBezSkrotu << " " << maxBezSkrotu << "\n";

    plik.close();
    wynik.close();

    return 0;
}